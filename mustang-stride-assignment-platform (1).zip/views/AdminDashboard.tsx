
import React, { useState } from 'react';
import { User, Assignment, Submission, Section, UserRole } from '../types';
import StatCard from '../components/StatCard';
import { analyzeResearchData } from '../geminiService';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

interface AdminDashboardProps {
  users: User[];
  assignments: Assignment[];
  submissions: Submission[];
  onAddUser: (user: Partial<User>) => void;
  onDeleteUser: (id: string) => void;
  onUpdateUser: (id: string, updates: Partial<User>) => void;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ users, assignments, submissions, onAddUser, onDeleteUser, onUpdateUser }) => {
  const [activeTab, setActiveTab] = useState<'stats' | 'users'>('stats');
  const [aiInsight, setAiInsight] = useState<string>('');
  const [loadingAi, setLoadingAi] = useState(false);
  const [confirmDeleteUser, setConfirmDeleteUser] = useState<User | null>(null);
  const [resettingUser, setResettingUser] = useState<User | null>(null);
  const [newPassword, setNewPassword] = useState('');

  // New User Form State
  const [newUserName, setNewUserName] = useState('');
  const [newUserPassword, setNewUserPassword] = useState('');
  const [newUserRole, setNewUserRole] = useState<UserRole>(UserRole.STUDENT);
  const [newUserSection, setNewUserSection] = useState<Section>(Section.EINSTEIN_G11);
  const [newUserSubject, setNewUserSubject] = useState('');

  const getStats = (section: Section) => {
    const sectionAssignments = assignments.filter(a => a.section === section);
    const sectionSubmissions = submissions.filter(s => {
      const ass = assignments.find(a => a.id === s.assignmentId);
      return ass?.section === section;
    });

    const totalExpected = sectionAssignments.length * users.filter(u => u.role === UserRole.STUDENT && u.section === section).length;
    const onTime = sectionSubmissions.filter(s => s.status === 'ON_TIME').length;
    const late = sectionSubmissions.filter(s => s.status === 'LATE').length;
    
    const rate = totalExpected > 0 ? Math.round(((onTime + late) / totalExpected) * 100) : 0;
    
    return { onTime, late, rate, total: onTime + late };
  };

  const einsteinStats = getStats(Section.EINSTEIN_G11);
  const galileiStats = getStats(Section.GALILEI_G12);

  const chartData = [
    { name: 'Einstein (On-Time)', value: einsteinStats.onTime, fill: '#10b981' },
    { name: 'Einstein (Late)', value: einsteinStats.late, fill: '#6ee7b7' },
    { name: 'Galilei (On-Time)', value: galileiStats.onTime, fill: '#059669' },
    { name: 'Galilei (Late)', value: galileiStats.late, fill: '#34d399' },
  ];

  const fetchAiInsight = async () => {
    setLoadingAi(true);
    const insight = await analyzeResearchData(assignments, submissions);
    setAiInsight(insight || '');
    setLoadingAi(false);
  };

  const handleExportData = () => {
    const researchData = {
      exportedAt: new Date().toISOString(),
      platform: "Mustang Stride",
      data: {
        users: users.map(u => ({ ...u, password: 'REDACTED_FOR_EXPORT' })),
        assignments,
        submissions
      }
    };
    
    const blob = new Blob([JSON.stringify(researchData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `mustang_stride_research_export_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    alert('Full research dataset exported successfully.');
  };

  const handleCreateUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUserName || !newUserPassword) return;
    
    if (newUserRole === UserRole.TEACHER && !newUserSubject) {
      alert("Please specify a subject for the teacher account.");
      return;
    }

    onAddUser({
      name: newUserName,
      username: newUserName.toLowerCase().replace(/\s+/g, '_'),
      password: newUserPassword,
      role: newUserRole,
      section: newUserRole === UserRole.ADMIN ? Section.NONE : newUserSection,
      subject: newUserRole === UserRole.TEACHER ? newUserSubject : undefined
    });

    setNewUserName('');
    setNewUserPassword('');
    setNewUserSubject('');
    alert(`Account for ${newUserName} has been created.`);
  };

  const UserTable = ({ title, sectionUsers }: { title: string, sectionUsers: User[] }) => (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden flex flex-col h-full">
      <div className="px-6 py-4 border-b border-gray-100 bg-gray-50/50 flex justify-between items-center">
        <h3 className="font-bold text-gray-800 flex items-center">
          <span className="w-2 h-2 bg-emerald-500 rounded-full mr-2"></span>
          {title}
        </h3>
        <span className="text-xs font-bold text-gray-400 bg-white px-2 py-1 rounded border border-gray-100">
          {sectionUsers.length} Users
        </span>
      </div>
      <div className="overflow-x-auto flex-1">
        <table className="w-full text-left">
          <thead>
            <tr className="text-[10px] uppercase text-gray-400 font-black tracking-widest border-b border-gray-50">
              <th className="px-6 py-4">Participant</th>
              <th className="px-6 py-4">Role/Subject</th>
              <th className="px-6 py-4 text-center">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-50">
            {sectionUsers.length === 0 ? (
              <tr>
                <td colSpan={3} className="px-6 py-10 text-center text-gray-400 text-sm italic">No participants registered in this field.</td>
              </tr>
            ) : (
              sectionUsers.map(u => (
                <tr key={u.id} className="hover:bg-gray-50/50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="font-bold text-gray-900 text-sm">{u.name}</div>
                    <div className="text-[10px] font-mono text-gray-400 uppercase tracking-tighter">PWD: {u.password}</div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-0.5 rounded text-[9px] font-black uppercase ${
                      u.role === UserRole.ADMIN ? 'bg-purple-100 text-purple-700' : 
                      u.role === UserRole.TEACHER ? 'bg-emerald-100 text-emerald-700' : 'bg-blue-100 text-blue-700'
                    }`}>
                      {u.role}
                    </span>
                    {u.subject && <div className="text-[10px] text-emerald-600 font-bold mt-1 line-clamp-1">{u.subject}</div>}
                  </td>
                  <td className="px-6 py-4 text-center">
                    <div className="flex items-center justify-center space-x-1">
                      <button 
                        onClick={() => setResettingUser(u)}
                        className="p-2 text-gray-400 hover:text-emerald-600 transition-colors"
                        title="Reset Password"
                      >
                        <i className="fas fa-key"></i>
                      </button>
                      <button 
                        onClick={() => setConfirmDeleteUser(u)}
                        className="p-2 text-gray-400 hover:text-rose-600 transition-colors"
                        title="Remove User"
                      >
                        <i className="fas fa-trash-alt"></i>
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Mustang Stride Admin</h2>
          <p className="text-gray-500 text-sm font-medium">Research Monitoring & Account Management</p>
        </div>
        <div className="flex bg-gray-200 p-1.5 rounded-2xl w-fit shadow-inner">
          <button 
            onClick={() => setActiveTab('stats')}
            className={`px-6 py-2.5 rounded-xl text-sm font-bold transition-all ${activeTab === 'stats' ? 'bg-white shadow-lg text-emerald-600' : 'text-gray-500 hover:text-gray-700'}`}
          >
            <i className="fas fa-chart-pie mr-2"></i> Analytics
          </button>
          <button 
            onClick={() => setActiveTab('users')}
            className={`px-6 py-2.5 rounded-xl text-sm font-bold transition-all ${activeTab === 'users' ? 'bg-white shadow-lg text-emerald-600' : 'text-gray-500 hover:text-gray-700'}`}
          >
            <i className="fas fa-users-cog mr-2"></i> Participants
          </button>
        </div>
      </div>

      {activeTab === 'stats' ? (
        <div className="space-y-8 animate-in fade-in duration-500">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <StatCard title="Einstein ON-TIME" value={`${einsteinStats.rate}%`} icon="fa-atom" color="bg-emerald-500" subtitle={`${einsteinStats.total} total submissions`} />
            <StatCard title="Einstein Late" value={einsteinStats.late} icon="fa-clock" color="bg-emerald-400" />
            <StatCard title="Galilei ON-TIME" value={`${galileiStats.rate}%`} icon="fa-telescope" color="bg-emerald-700" subtitle={`${galileiStats.total} total submissions`} />
            <StatCard title="Galilei Late" value={galileiStats.late} icon="fa-hourglass-half" color="bg-emerald-600" />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 bg-white p-8 rounded-3xl border border-gray-100 shadow-sm">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-lg font-bold text-gray-800">Cross-Section Comparison</h3>
                <button 
                  onClick={handleExportData}
                  className="px-4 py-2 bg-emerald-50 text-emerald-700 rounded-xl text-xs font-black hover:bg-emerald-100 transition-colors flex items-center space-x-2 border border-emerald-100"
                >
                  <i className="fas fa-file-export"></i>
                  <span>Master Export (.json)</span>
                </button>
              </div>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f3f4f6" />
                    <XAxis dataKey="name" fontSize={10} fontWeight="700" axisLine={false} tickLine={false} />
                    <YAxis fontSize={10} axisLine={false} tickLine={false} />
                    <Tooltip contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)' }} />
                    <Bar dataKey="value" radius={[10, 10, 0, 0]}>
                      {chartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.fill} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="bg-emerald-950 text-white p-10 rounded-3xl shadow-2xl relative overflow-hidden flex flex-col justify-between">
              <div className="relative z-10">
                <div className="flex items-center space-x-2 mb-4">
                  <div className="bg-emerald-500/20 p-2 rounded-lg">
                    <i className="fas fa-microchip text-emerald-400"></i>
                  </div>
                  <h3 className="text-lg font-bold">Stride Analyst AI</h3>
                </div>
                <div className="bg-emerald-900/40 p-5 rounded-2xl border border-emerald-800/50">
                  <p className="text-emerald-100 text-sm leading-relaxed min-h-[140px]">
                    {aiInsight || "Ready to evaluate performance patterns. Generate an executive summary to identify which section is optimizing their academic stride."}
                  </p>
                </div>
              </div>
              <button 
                onClick={fetchAiInsight}
                disabled={loadingAi}
                className="mt-6 w-full py-4 bg-emerald-500 text-emerald-950 rounded-2xl font-black hover:bg-emerald-400 transition-all disabled:opacity-50 shadow-xl shadow-emerald-500/20 relative z-10"
              >
                {loadingAi ? 'Decoding Trends...' : 'Run Performance Audit'}
              </button>
              <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-2xl"></div>
              <div className="absolute bottom-0 left-0 w-24 h-24 bg-emerald-400/5 rounded-full translate-y-1/2 -translate-x-1/2 blur-2xl"></div>
            </div>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 animate-in slide-in-from-bottom-4 duration-500">
          <div className="lg:col-span-4 space-y-6">
            <div className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm sticky top-28">
              <h3 className="text-xl font-bold mb-6 text-gray-900">Register Participant</h3>
              <form onSubmit={handleCreateUser} className="space-y-4">
                <div>
                  <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Full Name</label>
                  <input 
                    type="text" 
                    required
                    value={newUserName}
                    onChange={(e) => setNewUserName(e.target.value)}
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-2xl focus:ring-2 focus:ring-emerald-500 outline-none transition-all text-sm" 
                    placeholder="Enter full name" 
                  />
                </div>
                <div>
                  <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Initial Password</label>
                  <input 
                    type="text" 
                    required
                    value={newUserPassword}
                    onChange={(e) => setNewUserPassword(e.target.value)}
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-2xl focus:ring-2 focus:ring-emerald-500 outline-none transition-all text-sm" 
                    placeholder="Create secret key" 
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Role</label>
                    <select 
                      value={newUserRole}
                      onChange={(e) => {
                        const role = e.target.value as UserRole;
                        setNewUserRole(role);
                        if (role !== UserRole.TEACHER) setNewUserSubject('');
                      }}
                      className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-2xl focus:ring-2 focus:ring-emerald-500 outline-none text-sm font-bold"
                    >
                      <option value={UserRole.STUDENT}>Student</option>
                      <option value={UserRole.TEACHER}>Teacher</option>
                      <option value={UserRole.ADMIN}>Admin</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Section</label>
                    <select 
                      value={newUserSection}
                      disabled={newUserRole === UserRole.ADMIN}
                      onChange={(e) => setNewUserSection(e.target.value as Section)}
                      className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-2xl focus:ring-2 focus:ring-emerald-500 outline-none text-sm font-bold disabled:opacity-40"
                    >
                      <option value={Section.EINSTEIN_G11}>Einstein (G11)</option>
                      <option value={Section.GALILEI_G12}>Galilei (G12)</option>
                    </select>
                  </div>
                </div>

                {newUserRole === UserRole.TEACHER && (
                  <div className="animate-in fade-in zoom-in duration-300">
                    <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Specialization</label>
                    <input 
                      type="text" 
                      required
                      value={newUserSubject}
                      onChange={(e) => setNewUserSubject(e.target.value)}
                      className="w-full px-4 py-3 bg-emerald-50 border border-emerald-100 rounded-2xl focus:ring-2 focus:ring-emerald-500 outline-none text-sm text-emerald-800 font-bold" 
                      placeholder="e.g. Theoretical Physics" 
                    />
                  </div>
                )}

                <button className="w-full py-4 bg-emerald-600 text-white rounded-2xl font-black shadow-lg shadow-emerald-100 hover:bg-emerald-700 transition-all mt-4 active:scale-95">
                  Confirm Enrollment
                </button>
              </form>
            </div>
          </div>

          <div className="lg:col-span-8 space-y-8">
            <div className="grid grid-cols-1 xl:grid-cols-2 gap-8 h-full">
              <UserTable 
                title="Einstein Field (Grade 11)" 
                sectionUsers={users.filter(u => u.section === Section.EINSTEIN_G11)} 
              />
              <UserTable 
                title="Galilei Field (Grade 12)" 
                sectionUsers={users.filter(u => u.section === Section.GALILEI_G12)} 
              />
            </div>
            
            <div className="bg-purple-50 p-6 rounded-3xl border border-purple-100">
              <h3 className="text-xs font-black text-purple-700 uppercase tracking-widest mb-4 flex items-center">
                <i className="fas fa-shield-halved mr-2"></i> System Administrators
              </h3>
              <div className="flex flex-wrap gap-3">
                {users.filter(u => u.role === UserRole.ADMIN).map(admin => (
                  <div key={admin.id} className="bg-white px-4 py-3 rounded-2xl border border-purple-200 shadow-sm flex items-center space-x-3">
                    <div className="w-8 h-8 rounded-full bg-purple-100 text-purple-600 flex items-center justify-center text-xs font-black">
                      {admin.name.charAt(0)}
                    </div>
                    <div>
                      <div className="text-sm font-bold text-gray-900">{admin.name}</div>
                      <div className="text-[10px] text-purple-500 font-bold uppercase">Root Access</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Reset Password Modal */}
      {resettingUser && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[200] flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-3xl shadow-2xl overflow-hidden animate-in zoom-in duration-200">
            <div className="p-8">
              <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="fas fa-key text-2xl"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2 text-center">Reset Key</h3>
              <p className="text-sm text-gray-500 mb-6 text-center">
                Setting a new credentials for <span className="font-bold text-gray-900">{resettingUser.name}</span>.
              </p>
              <input 
                type="text" 
                autoFocus
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="New Password..."
                className="w-full px-5 py-3 bg-gray-50 border border-gray-200 rounded-2xl focus:ring-2 focus:ring-emerald-500 outline-none text-center font-bold mb-6"
              />
              <div className="flex flex-col space-y-3">
                <button 
                  onClick={() => {
                    if (!newPassword) return;
                    onUpdateUser(resettingUser.id, { password: newPassword });
                    alert(`Password updated to: ${newPassword}`);
                    setResettingUser(null);
                    setNewPassword('');
                  }}
                  className="w-full py-3.5 bg-emerald-600 text-white rounded-xl font-bold shadow-lg shadow-emerald-100"
                >
                  Save New Key
                </button>
                <button 
                  onClick={() => { setResettingUser(null); setNewPassword(''); }}
                  className="w-full py-3.5 bg-gray-50 text-gray-500 rounded-xl font-bold"
                >
                  Dismiss
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {confirmDeleteUser && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[200] flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-3xl shadow-2xl overflow-hidden animate-in zoom-in duration-200">
            <div className="p-8 text-center">
              <div className="w-16 h-16 bg-rose-100 text-rose-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="fas fa-user-slash text-2xl"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Unenroll Participant?</h3>
              <p className="text-sm text-gray-500 mb-8 leading-relaxed">
                Are you sure you want to remove <span className="font-bold text-gray-900">{confirmDeleteUser.name}</span> from the study?
              </p>
              <div className="flex flex-col space-y-3">
                <button 
                  onClick={() => { onDeleteUser(confirmDeleteUser.id); setConfirmDeleteUser(null); }}
                  className="w-full py-3.5 bg-rose-600 text-white rounded-xl font-bold shadow-lg shadow-rose-100 hover:bg-rose-700 transition-colors"
                >
                  Yes, Remove Access
                </button>
                <button 
                  onClick={() => setConfirmDeleteUser(null)}
                  className="w-full py-3.5 bg-gray-50 text-gray-500 rounded-xl font-bold hover:bg-gray-100 transition-colors"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminDashboard;
